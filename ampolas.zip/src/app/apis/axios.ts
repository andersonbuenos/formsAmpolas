/* import axios from "axios";
const axiosConfig = {
  baseURL:"https://servicodados.ibge.gov.br/api/v1/localidades/estados/50/municipios"
};

export const api = axios.create(axiosConfig);
 */
