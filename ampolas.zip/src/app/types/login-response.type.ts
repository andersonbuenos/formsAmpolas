export type LoginResponse = {
    token: string,
    name: string
}